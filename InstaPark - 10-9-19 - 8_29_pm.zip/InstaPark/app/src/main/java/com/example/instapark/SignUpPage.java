package com.example.instapark;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpPage extends AppCompatActivity {
    public static String username = "err";
    public static String pass = "err";
    public static String Repass = "err";

    public void signUpButtonIsPressed(View signUpButton){
        EditText usernameEntry = findViewById(R.id.username_entry);
        EditText passwordEntry = findViewById(R.id.password_entry);
        EditText passwordReEntry = findViewById(R.id.password_re_entry);

        username = usernameEntry.getText().toString();
        pass = passwordEntry.getText().toString();
        Repass = passwordReEntry.getText().toString();



        if (Repass.equals(pass)){
            // FireBase Initialization
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("UserData").child(username).child("Information");
            myRef.child(username);
            myRef.child("username").setValue(usernameEntry.getText().toString());
            myRef.child("password").setValue(passwordEntry.getText().toString());

            Toast.makeText(this, "You have signed up! Now login to continue", Toast.LENGTH_LONG).show();

            Intent intent = new Intent(this, LoginScreen.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(this, "Password and repeat password do not match", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page);
    }
}
